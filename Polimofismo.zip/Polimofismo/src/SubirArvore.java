public interface SubirArvore {
    void subirEmArvore();
}
