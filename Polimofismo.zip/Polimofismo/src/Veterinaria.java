public class Veterinaria  {
    public void examinar(Animal animal){
        animal.emitirSom();
        System.out.println("Animal examinado com sucesso");
    }
}
