public abstract class Animal{
    protected String nome;
    protected  int idade;
    public abstract void emitirSom();

}
