public interface deveCorrer {
    void correr();
}
